findmePath=$1
searchType=$2

if [[ "$searchType" == "wifi" ]]
then
	if [[ `$findmePath` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -tm
	elif [[ `$findmePath -k` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -tk
	elif [[ `$findmePath -a` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -ta
	else
		$findmePath -t
	fi
elif [[ "$searchType" == "ip" ]]
then
	if [[ `$findmePath -i` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -it
	elif [[ `$findmePath -ik` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -itk
	elif [[ `$findmePath -ia` != "Error: Could not detect latitude and/or longitude" ]]
	then
		$findmePath -ita
	else
		$findmePath -it
	fi
elif [[ "$searchType" == "cell" ]]
then
	$findmePath -gt
else
	echo "Bad search argument"
fi