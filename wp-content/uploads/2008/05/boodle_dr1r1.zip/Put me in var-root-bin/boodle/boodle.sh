#!/bin/sh
#
#	Boodle DR1r1
#	Based heavily upon WeeGee v0.01 by Fuel
#
#	The script will monitor the Photos directory and Internet access.
# 	If internet access is detected, it will check a dedicated website
#	to see if the iPhone is stolen. If so, it will do the following:
#	
#	*	(Optionally) Update a twitter account periodically with the iPhone's location (at a rate determined by com.semifluid.boodle.plist)
#	*	Creates a gzip archive of the location, recent calls, web sites and SMS and email it to you
#	*	Finds latest camera photos, compresses them, and emails them to you
#
#

# Variables
# -----------------------------------------------
# Only run if the iPhone is reported stolen
# watchResponse Examples:
# 	On a dedicated server:
# 		`curl -s -4 theIPAddress/boodle.php`
# 	With shared hosting:
# 		`curl -s -4 theSharedIP/boodle.php -H 'Host: www.theSharedAddress.com'`
#	If you don't know the IP address (least favorable because of potential DNS problems)
# 		`curl -s www.theAddress.com/boodle.php`
# MAKE SURE TO CHANGE TO YOUR SERVER
watchResponse=`curl -s "www.random.org/integers/?num=1&min=0&max=1&col=1&base=10&format=plain&rnd=new"`

workPath="/var/root/bin/boodle"			# Path of working directory
mailsendPath="$workPath/mailsend"			# Path of mailsend binary
resizePath="$workPath/reduceJPEG"			# Path of resizeJPEG binary

smtpServer="64.233.167.109"				# Gmail server
smtpServerPort="587"					# Gmail server
emailUsername="USERNAME"				# SMTP Username
emailPassword="PASSWORD"				# SMTP Password
toEmail="theEmail@theServer.com"			# Address to send reports to

JPEGMaxWidth=800					# Resize JPEGs to this maximum width
JPEGQuality=75					# JPEG quality
# -----------------------------------------------
trackLocation=1					# 1 = Send updates to Twitter every time script is run, 0 = Off
findmePath="$workPath/findme-muchbetter"		# Path of findme-muchbetter binary
findLocationPath="$workPath/findLocation.sh"	# Path of findLocation.sh
pingwifiPath="$workPath/pingwifi"			# Path of pingwifi binary
twitterUsername="USERNAME"				# Twitter username
twitterPassword="PASSWORD"				# Twitter password
# -----------------------------------------------

if [ ! -r $workPath ]
then
	mkdir $workPath
fi

echo "Starting boodle"
currentTime=`date "+%y-%m-%d %H:%M:%S"`

# Ping the Wifi to wake things up
$pingwifiPath
sleep 10

# Get location information
echo "Retrieving location information"
locWifi=`$findLocationPath $findmePath "wifi"`
locCell=`$findLocationPath $findmePath "cell"`
locIP=`$findLocationPath $findmePath "ip"`

# Twitter Update
# -----------------------------------------------
if [ "$trackLocation" -eq 1 ]
then
	echo "Tweet..."
	curl --basic --user $twitterUsername:$twitterPassword --data status="Wifi: $locWifi" http://twitter.com/statuses/update.xml
	#curl --basic --user twitterUsername:twitterPassword --data status="Cell: $locWifi" http://twitter.com/statuses/update.xml
	#curl --basic --user twitterUsername:twitterPassword --data status="IP: $locWifi" http://twitter.com/statuses/update.xml
fi
# -----------------------------------------------

# Stolen, and need to reset time stamp
if [ "$watchResponse" -eq 3 ]
then
	echo "Stolen, reset time stamp"
	if [ -r $workPath/boodleTS.txt ]
	then
		rm -f $workPath/boodleTS.txt
	fi
	watchResponse=1
fi

# Phone stolen!
if [ "$watchResponse" -eq 1 ]
then
	echo "Phone flagged as stolen!"
	
	echo "Saving location information..."
	echo "Skyhook wifi search:" >  $workPath/location.txt
	echo $locWifi >>  $workPath/location.txt
	echo "Google maps cell tower search:" >>  $workPath/location.txt
	echo $locCell >> $workPath/location.txt
	echo "Skyhook ip search:" >>  $workPath/location.txt
	echo $locIP >> $workPath/location.txt

	echo "Archiving recent call data..."
	sqlite3 /var/mobile/Library/CallHistory/call_history.db .dump > $workPath/callhist.sql
	echo "Archiving SMS history..."
	sqlite3 /var/mobile/Library/SMS/sms.db .dump > $workPath/sms.sql
	echo "Archiving web history..."
	cp /var/mobile/Library/Safari/History.plist $workPath/web.plist
	
	# Archive the database information
	tar -cf $workPath/boodle_hist.tar $workPath/location.txt $workPath/callhist.sql $workPath/web.plist $workPath/sms.sql 
	gzip -f $workPath/boodle_hist.tar
	
	rm $workPath/location.txt
	rm $workPath/callhist.sql
	rm $workPath/web.plist
	rm $workPath/sms.sql
	
	# -----------------------------------------------
	# Now, prepare the images. We first check to see if there are any new 
	# JPEGs since the last time we ran this script... if so, then we resize
	# them, archive them and send them via email.
	
	if [ -r $workPath/boodleTS.txt ]
	then
		find /var/mobile/Media/DCIM -name *.JPG -newer $workPath/boodleTS.txt -exec cp {} $workPath/ \;
	else
		find /var/mobile/Media/DCIM -name *.JPG -exec cp {} $workPath/ \;
	fi

	cmdResponse=`ls -l $workPath/*.JPG`
	if [ "$cmdResponse" != "" ]
	then
		for origpic in $workPath/*.JPG
		do
			$resizePath $origpic $JPEGMaxWidth $JPEGQuality
		done
		tar -cf $workPath/boodle_img.tar $workPath/*.JPG
		gzip -f $workPath/boodle_img.tar
	fi
	rm -f $workPath/*.JPG
	# -----------------------------------------------
	
	# Email commands for sending data
	mailDB="$mailsendPath -starttls -port $smtpServerPort -smtp $smtpServer -auth -user $emailUsername -pass $emailPassword -f emailUsername -t $toEmail -sub iPhone_STOLEN_Database_report -attach "
	mailIMGs="$mailsendPath -starttls -port $smtpServerPort -smtp $smtpServer -auth -user $emailUsername -pass $emailPassword -f emailUsername -t $toEmail -sub iPhone_STOLEN_Image_report -attach "

	echo "Sending databases"
	$mailDB $workPath/boodle_hist.tar.gz
	rm -f $workPath/boodle_hist.tar.gz

	if [ -r $workPath/boodle_img.tar.gz ]
	then
		echo "Sending images"
		$mailIMGs $workPath/boodle_img.tar.gz
		rm -f $workPath/boodle_img.tar.gz
	fi

	echo "Modifying $workPath/boodleTS.txt with current timestamp"
	if [ -r $workPath/boodleTS.txt ]
	then
		rm -f $workPath/boodleTS.txt
	fi
	echo $currentTime > $workPath/boodleTS.txt
elif [ "$watchResponse" -eq 0 ]
then
	# All clear
	echo "All clear"
elif [ "$watchResponse" -eq 2 ]
then
	# All clear, reset time stamp
	echo "All clear, reset time stamp"
	if [ -r $workPath/boodleTS.txt ]
	then
		rm -f $workPath/boodleTS.txt
	fi
fi