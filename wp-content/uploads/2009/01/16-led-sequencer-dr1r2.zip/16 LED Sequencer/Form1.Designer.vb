<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.colorBoxRed = New System.Windows.Forms.PictureBox
        Me.colorBoxGreen = New System.Windows.Forms.PictureBox
        Me.colorBoxBlue = New System.Windows.Forms.PictureBox
        Me.colorBoxSelected = New System.Windows.Forms.PictureBox
        Me.txtRows = New System.Windows.Forms.TextBox
        Me.txtColumns = New System.Windows.Forms.TextBox
        Me.colorDisplay = New System.Windows.Forms.PictureBox
        Me.buttonAddChange = New System.Windows.Forms.Button
        Me.colorMovie = New System.Windows.Forms.PictureBox
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar
        Me.buttonLoad = New System.Windows.Forms.Button
        Me.buttonSave = New System.Windows.Forms.Button
        Me.txtPeriod = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtInfo = New System.Windows.Forms.TextBox
        Me.buttonPlayStop = New System.Windows.Forms.Button
        Me.timerPlayMovie = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.scrollBarSpeed = New System.Windows.Forms.HScrollBar
        Me.checkEnableSerial = New System.Windows.Forms.CheckBox
        CType(Me.colorBoxRed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.colorBoxGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.colorBoxBlue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.colorBoxSelected, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.colorDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.colorMovie, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'colorBoxRed
        '
        Me.colorBoxRed.Location = New System.Drawing.Point(15, 48)
        Me.colorBoxRed.Name = "colorBoxRed"
        Me.colorBoxRed.Size = New System.Drawing.Size(256, 20)
        Me.colorBoxRed.TabIndex = 0
        Me.colorBoxRed.TabStop = False
        '
        'colorBoxGreen
        '
        Me.colorBoxGreen.Location = New System.Drawing.Point(15, 74)
        Me.colorBoxGreen.Name = "colorBoxGreen"
        Me.colorBoxGreen.Size = New System.Drawing.Size(256, 20)
        Me.colorBoxGreen.TabIndex = 1
        Me.colorBoxGreen.TabStop = False
        '
        'colorBoxBlue
        '
        Me.colorBoxBlue.Location = New System.Drawing.Point(15, 100)
        Me.colorBoxBlue.Name = "colorBoxBlue"
        Me.colorBoxBlue.Size = New System.Drawing.Size(256, 20)
        Me.colorBoxBlue.TabIndex = 2
        Me.colorBoxBlue.TabStop = False
        '
        'colorBoxSelected
        '
        Me.colorBoxSelected.Location = New System.Drawing.Point(277, 48)
        Me.colorBoxSelected.Name = "colorBoxSelected"
        Me.colorBoxSelected.Size = New System.Drawing.Size(72, 72)
        Me.colorBoxSelected.TabIndex = 3
        Me.colorBoxSelected.TabStop = False
        '
        'txtRows
        '
        Me.txtRows.Location = New System.Drawing.Point(199, -4)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.ReadOnly = True
        Me.txtRows.Size = New System.Drawing.Size(40, 20)
        Me.txtRows.TabIndex = 4
        Me.txtRows.Text = "2"
        Me.txtRows.Visible = False
        '
        'txtColumns
        '
        Me.txtColumns.Location = New System.Drawing.Point(199, 22)
        Me.txtColumns.Name = "txtColumns"
        Me.txtColumns.ReadOnly = True
        Me.txtColumns.Size = New System.Drawing.Size(40, 20)
        Me.txtColumns.TabIndex = 6
        Me.txtColumns.Text = "2"
        Me.txtColumns.Visible = False
        '
        'colorDisplay
        '
        Me.colorDisplay.Location = New System.Drawing.Point(15, 124)
        Me.colorDisplay.Name = "colorDisplay"
        Me.colorDisplay.Size = New System.Drawing.Size(168, 168)
        Me.colorDisplay.TabIndex = 8
        Me.colorDisplay.TabStop = False
        '
        'buttonAddChange
        '
        Me.buttonAddChange.Location = New System.Drawing.Point(115, 298)
        Me.buttonAddChange.Name = "buttonAddChange"
        Me.buttonAddChange.Size = New System.Drawing.Size(68, 29)
        Me.buttonAddChange.TabIndex = 9
        Me.buttonAddChange.Text = "Add"
        Me.buttonAddChange.UseVisualStyleBackColor = True
        '
        'colorMovie
        '
        Me.colorMovie.Location = New System.Drawing.Point(189, 124)
        Me.colorMovie.Name = "colorMovie"
        Me.colorMovie.Size = New System.Drawing.Size(168, 168)
        Me.colorMovie.TabIndex = 10
        Me.colorMovie.TabStop = False
        '
        'HScrollBar1
        '
        Me.HScrollBar1.LargeChange = 1
        Me.HScrollBar1.Location = New System.Drawing.Point(189, 299)
        Me.HScrollBar1.Maximum = 0
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(168, 28)
        Me.HScrollBar1.TabIndex = 11
        '
        'buttonLoad
        '
        Me.buttonLoad.Location = New System.Drawing.Point(15, 13)
        Me.buttonLoad.Name = "buttonLoad"
        Me.buttonLoad.Size = New System.Drawing.Size(86, 29)
        Me.buttonLoad.TabIndex = 12
        Me.buttonLoad.Text = "Load Movie"
        Me.buttonLoad.UseVisualStyleBackColor = True
        '
        'buttonSave
        '
        Me.buttonSave.Location = New System.Drawing.Point(107, 13)
        Me.buttonSave.Name = "buttonSave"
        Me.buttonSave.Size = New System.Drawing.Size(86, 29)
        Me.buttonSave.TabIndex = 13
        Me.buttonSave.Text = "Save Movie"
        Me.buttonSave.UseVisualStyleBackColor = True
        '
        'txtPeriod
        '
        Me.txtPeriod.Location = New System.Drawing.Point(69, 303)
        Me.txtPeriod.Name = "txtPeriod"
        Me.txtPeriod.Size = New System.Drawing.Size(40, 20)
        Me.txtPeriod.TabIndex = 14
        Me.txtPeriod.Text = "50"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 306)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Period (ms)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtInfo
        '
        Me.txtInfo.Location = New System.Drawing.Point(15, 334)
        Me.txtInfo.Multiline = True
        Me.txtInfo.Name = "txtInfo"
        Me.txtInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInfo.Size = New System.Drawing.Size(342, 97)
        Me.txtInfo.TabIndex = 16
        '
        'buttonPlayStop
        '
        Me.buttonPlayStop.Location = New System.Drawing.Point(199, 13)
        Me.buttonPlayStop.Name = "buttonPlayStop"
        Me.buttonPlayStop.Size = New System.Drawing.Size(86, 29)
        Me.buttonPlayStop.TabIndex = 17
        Me.buttonPlayStop.Text = "Play Movie"
        Me.buttonPlayStop.UseVisualStyleBackColor = True
        '
        'timerPlayMovie
        '
        '
        'scrollBarSpeed
        '
        Me.scrollBarSpeed.LargeChange = 1
        Me.scrollBarSpeed.Location = New System.Drawing.Point(288, 13)
        Me.scrollBarSpeed.Maximum = 50
        Me.scrollBarSpeed.Minimum = 5
        Me.scrollBarSpeed.Name = "scrollBarSpeed"
        Me.scrollBarSpeed.Size = New System.Drawing.Size(61, 28)
        Me.scrollBarSpeed.TabIndex = 18
        Me.scrollBarSpeed.Value = 10
        '
        'checkEnableSerial
        '
        Me.checkEnableSerial.AutoSize = True
        Me.checkEnableSerial.Location = New System.Drawing.Point(353, 13)
        Me.checkEnableSerial.Name = "checkEnableSerial"
        Me.checkEnableSerial.Size = New System.Drawing.Size(15, 14)
        Me.checkEnableSerial.TabIndex = 19
        Me.checkEnableSerial.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(369, 441)
        Me.Controls.Add(Me.checkEnableSerial)
        Me.Controls.Add(Me.scrollBarSpeed)
        Me.Controls.Add(Me.buttonPlayStop)
        Me.Controls.Add(Me.txtInfo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtPeriod)
        Me.Controls.Add(Me.buttonSave)
        Me.Controls.Add(Me.buttonLoad)
        Me.Controls.Add(Me.HScrollBar1)
        Me.Controls.Add(Me.colorMovie)
        Me.Controls.Add(Me.buttonAddChange)
        Me.Controls.Add(Me.colorDisplay)
        Me.Controls.Add(Me.txtColumns)
        Me.Controls.Add(Me.txtRows)
        Me.Controls.Add(Me.colorBoxSelected)
        Me.Controls.Add(Me.colorBoxBlue)
        Me.Controls.Add(Me.colorBoxGreen)
        Me.Controls.Add(Me.colorBoxRed)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.colorBoxRed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.colorBoxGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.colorBoxBlue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.colorBoxSelected, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.colorDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.colorMovie, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents colorBoxRed As System.Windows.Forms.PictureBox
    Friend WithEvents colorBoxGreen As System.Windows.Forms.PictureBox
    Friend WithEvents colorBoxBlue As System.Windows.Forms.PictureBox
    Friend WithEvents colorBoxSelected As System.Windows.Forms.PictureBox
    Friend WithEvents txtRows As System.Windows.Forms.TextBox
    Friend WithEvents txtColumns As System.Windows.Forms.TextBox
    Friend WithEvents colorDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents buttonAddChange As System.Windows.Forms.Button
    Friend WithEvents colorMovie As System.Windows.Forms.PictureBox
    Friend WithEvents HScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents buttonLoad As System.Windows.Forms.Button
    Friend WithEvents buttonSave As System.Windows.Forms.Button
    Friend WithEvents txtPeriod As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtInfo As System.Windows.Forms.TextBox
    Friend WithEvents buttonPlayStop As System.Windows.Forms.Button
    Friend WithEvents timerPlayMovie As System.Windows.Forms.Timer
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents scrollBarSpeed As System.Windows.Forms.HScrollBar
    Friend WithEvents checkEnableSerial As System.Windows.Forms.CheckBox

End Class
