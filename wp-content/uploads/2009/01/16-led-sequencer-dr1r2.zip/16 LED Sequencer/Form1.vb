Public Class Form1
    Dim colorSelectedRed As Integer
    Dim colorSelectedGreen As Integer
    Dim colorSelectedBlue As Integer
    Dim blockSelected(1) As Integer
    Dim blockColor(1, 1, 2) As Integer
    Dim movieColor(100, 1, 1, 2) As Integer
    Dim moviePeriod(100) As Integer
    Dim currentFrame As Integer
    Dim totalFrames As Integer

    Private Sub colorBoxRed_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxRed.MouseClick
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedRed = Fix(e.X / colorBoxRed.Width * 16)
            If colorSelectedRed < 0 Then colorSelectedRed = 0
            If colorSelectedRed > 15 Then colorSelectedRed = 15
            colorBoxRed.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxRed_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxRed.MouseMove
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedRed = Fix(e.X / colorBoxRed.Width * 16)
            If colorSelectedRed < 0 Then colorSelectedRed = 0
            If colorSelectedRed > 15 Then colorSelectedRed = 15
            colorBoxRed.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxRed_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorBoxRed.Paint
        Dim i As Integer

        For i = 0 To 15
            ' Create brush
            Dim theBrush As New SolidBrush(Color.FromArgb(i * 17, 0, 0))
            ' Create rectangle.
            Dim rect As New Rectangle(i * colorBoxRed.Width / 16, 0, colorBoxRed.Width / 16, colorBoxRed.Height)
            ' Draw rectangle to screen.
            e.Graphics.FillRectangle(theBrush, rect)
        Next

        Dim thePen As New Pen(Color.FromArgb(127, 127, 127), 3)
        ' Create rectangle.
        Dim outlinerect As New Rectangle(colorSelectedRed * colorBoxRed.Width / 16, 0, colorBoxRed.Width / 16, colorBoxRed.Height)
        ' Draw rectangle to screen.
        e.Graphics.DrawRectangle(thePen, outlinerect)
    End Sub

    Private Sub colorBoxBlue_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxBlue.MouseClick
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedBlue = Fix(e.X / colorBoxBlue.Width * 16)
            If colorSelectedBlue < 0 Then colorSelectedBlue = 0
            If colorSelectedBlue > 15 Then colorSelectedBlue = 15
            colorBoxBlue.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxBlue_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxBlue.MouseMove
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedBlue = Fix(e.X / colorBoxBlue.Width * 16)
            If colorSelectedBlue < 0 Then colorSelectedBlue = 0
            If colorSelectedBlue > 15 Then colorSelectedBlue = 15
            colorBoxBlue.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxBlue_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorBoxBlue.Paint
        Dim i As Integer

        For i = 0 To 15
            ' Create brush
            Dim theBrush As New SolidBrush(Color.FromArgb(0, 0, i * 17))
            ' Create rectangle.
            Dim rect As New Rectangle(i * colorBoxBlue.Width / 16, 0, colorBoxBlue.Width / 16, colorBoxBlue.Height)
            ' Draw rectangle to screen.
            e.Graphics.FillRectangle(theBrush, rect)
        Next

        Dim thePen As New Pen(Color.FromArgb(127, 127, 127), 3)
        ' Create rectangle.
        Dim outlinerect As New Rectangle(colorSelectedBlue * colorBoxBlue.Width / 16, 0, colorBoxBlue.Width / 16, colorBoxBlue.Height)
        ' Draw rectangle to screen.
        e.Graphics.DrawRectangle(thePen, outlinerect)
    End Sub

    Private Sub colorBoxGreen_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxGreen.MouseClick
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedGreen = Fix(e.X / colorBoxGreen.Width * 16)
            If colorSelectedGreen < 0 Then colorSelectedGreen = 0
            If colorSelectedGreen > 15 Then colorSelectedGreen = 15
            colorBoxGreen.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxGreen_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorBoxGreen.MouseMove
        If e.Button() = Windows.Forms.MouseButtons.Left Then
            colorSelectedGreen = Fix(e.X / colorBoxGreen.Width * 16)
            If colorSelectedGreen < 0 Then colorSelectedGreen = 0
            If colorSelectedGreen > 15 Then colorSelectedGreen = 15
            colorBoxGreen.Refresh()
            colorBoxSelected.Refresh()
        End If
    End Sub

    Private Sub colorBoxGreen_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorBoxGreen.Paint
        Dim i As Integer

        For i = 0 To 15
            ' Create brush
            Dim theBrush As New SolidBrush(Color.FromArgb(0, i * 17, 0))
            ' Create rectangle.
            Dim rect As New Rectangle(i * colorBoxGreen.Width / 16, 0, colorBoxGreen.Width / 16, colorBoxGreen.Height)
            ' Draw rectangle to screen.
            e.Graphics.FillRectangle(theBrush, rect)
        Next

        Dim thePen As New Pen(Color.FromArgb(127, 127, 127), 3)
        ' Create rectangle.
        Dim outlinerect As New Rectangle(colorSelectedGreen * colorBoxGreen.Width / 16, 0, colorBoxGreen.Width / 16, colorBoxGreen.Height)
        ' Draw rectangle to screen.
        e.Graphics.DrawRectangle(thePen, outlinerect)
    End Sub

    Private Sub colorBoxSelected_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorBoxSelected.Paint
        ' Create brush
        Dim theBrush As New SolidBrush(Color.FromArgb(colorSelectedRed * 17, colorSelectedGreen * 17, colorSelectedBlue * 17))
        ' Create rectangle.
        Dim rect As New Rectangle(0, 0, colorBoxSelected.Width, colorBoxSelected.Height)
        ' Draw rectangle to screen.
        e.Graphics.FillRectangle(theBrush, rect)

        blockColor(blockSelected(0), blockSelected(1), 0) = colorSelectedRed * 17
        blockColor(blockSelected(0), blockSelected(1), 1) = colorSelectedGreen * 17
        blockColor(blockSelected(0), blockSelected(1), 2) = colorSelectedBlue * 17
        colorDisplay.Refresh()
    End Sub

    Private Sub colorDisplay_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorDisplay.MouseClick
        If (e.Button() = Windows.Forms.MouseButtons.Left) Or (e.Button() = Windows.Forms.MouseButtons.Right) Then
            blockSelected(0) = Fix(e.X / colorDisplay.Width * (Val(txtRows.Text) * 2))
            blockSelected(1) = Fix(e.Y / colorDisplay.Height * (Val(txtColumns.Text) * 2))
            If blockSelected(0) < 0 Then blockSelected(0) = 0
            If blockSelected(0) > Val(txtRows.Text) * 2 - 1 Then blockSelected(0) = Val(txtRows.Text) * 2 - 1
            If blockSelected(1) < 0 Then blockSelected(1) = 0
            If blockSelected(1) > Val(txtColumns.Text) * 2 - 1 Then blockSelected(1) = Val(txtColumns.Text) * 2 - 1
            If e.Button() = Windows.Forms.MouseButtons.Left Then
                colorSelectedRed = blockColor(blockSelected(0), blockSelected(1), 0) / 17
                colorSelectedGreen = blockColor(blockSelected(0), blockSelected(1), 1) / 17
                colorSelectedBlue = blockColor(blockSelected(0), blockSelected(1), 2) / 17
                colorBoxRed.Refresh()
                colorBoxGreen.Refresh()
                colorBoxBlue.Refresh()
                colorBoxSelected.Refresh()
            ElseIf e.Button() = Windows.Forms.MouseButtons.Right Then
                blockColor(blockSelected(0), blockSelected(1), 0) = colorSelectedRed * 17
                blockColor(blockSelected(0), blockSelected(1), 1) = colorSelectedGreen * 17
                blockColor(blockSelected(0), blockSelected(1), 2) = colorSelectedBlue * 17
            End If
            colorDisplay.Refresh()
        End If
    End Sub

    Private Sub colorDisplay_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles colorDisplay.MouseMove
        If (e.Button() = Windows.Forms.MouseButtons.Left) Or (e.Button() = Windows.Forms.MouseButtons.Right) Then
            blockSelected(0) = Fix(e.X / colorDisplay.Width * (Val(txtRows.Text) * 2))
            blockSelected(1) = Fix(e.Y / colorDisplay.Height * (Val(txtColumns.Text) * 2))
            If blockSelected(0) < 0 Then blockSelected(0) = 0
            If blockSelected(0) > Val(txtRows.Text) * 2 - 1 Then blockSelected(0) = Val(txtRows.Text) * 2 - 1
            If blockSelected(1) < 0 Then blockSelected(1) = 0
            If blockSelected(1) > Val(txtColumns.Text) * 2 - 1 Then blockSelected(1) = Val(txtColumns.Text) * 2 - 1
            If e.Button() = Windows.Forms.MouseButtons.Left Then
                colorSelectedRed = blockColor(blockSelected(0), blockSelected(1), 0) / 17
                colorSelectedGreen = blockColor(blockSelected(0), blockSelected(1), 1) / 17
                colorSelectedBlue = blockColor(blockSelected(0), blockSelected(1), 2) / 17
                colorBoxRed.Refresh()
                colorBoxGreen.Refresh()
                colorBoxBlue.Refresh()
                colorBoxSelected.Refresh()
            ElseIf e.Button() = Windows.Forms.MouseButtons.Right Then
                blockColor(blockSelected(0), blockSelected(1), 0) = colorSelectedRed * 17
                blockColor(blockSelected(0), blockSelected(1), 1) = colorSelectedGreen * 17
                blockColor(blockSelected(0), blockSelected(1), 2) = colorSelectedBlue * 17
            End If
            colorDisplay.Refresh()
        End If
    End Sub

    Private Sub colorDisplay_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorDisplay.Paint
        Dim i, j As Integer

        For i = 0 To Val(txtRows.Text) * 2 - 1
            For j = 0 To Val(txtColumns.Text) * 2 - 1
                ' Create brush
                Dim theBrush As New SolidBrush(Color.FromArgb(blockColor(i, j, 0), blockColor(i, j, 1), blockColor(i, j, 2)))
                ' Create rectangle.
                Dim rect As New Rectangle(i * colorDisplay.Width / (Val(txtRows.Text) * 2), j * colorDisplay.Height / (Val(txtColumns.Text) * 2), colorDisplay.Width / (Val(txtRows.Text) * 2), colorDisplay.Height / (Val(txtColumns.Text) * 2))
                ' Draw rectangle to screen.
                e.Graphics.FillRectangle(theBrush, rect)
            Next
        Next

        Dim thePen As New Pen(Color.FromArgb(127, 127, 127), 3)
        ' Create rectangle.
        Dim outlinerect As New Rectangle(blockSelected(0) * colorDisplay.Width / (Val(txtRows.Text) * 2), blockSelected(1) * colorDisplay.Height / (Val(txtColumns.Text) * 2), colorDisplay.Width / (Val(txtRows.Text) * 2), colorDisplay.Height / (Val(txtColumns.Text) * 2))
        ' Draw rectangle to screen.
        e.Graphics.DrawRectangle(thePen, outlinerect)
    End Sub

    Private Sub colorMovie_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles colorMovie.Paint
        Dim i, j As Integer

        For i = 0 To Val(txtRows.Text) * 2 - 1
            For j = 0 To Val(txtColumns.Text) * 2 - 1
                ' Create brush
                Dim theBrush As New SolidBrush(Color.FromArgb(movieColor(currentFrame, i, j, 0), movieColor(currentFrame, i, j, 1), movieColor(currentFrame, i, j, 2)))
                ' Create rectangle.
                Dim rect As New Rectangle(i * colorMovie.Width / (Val(txtRows.Text) * 2), j * colorMovie.Height / (Val(txtColumns.Text) * 2), colorMovie.Width / (Val(txtRows.Text) * 2), colorMovie.Height / (Val(txtColumns.Text) * 2))
                ' Draw rectangle to screen.
                e.Graphics.FillRectangle(theBrush, rect)
            Next
        Next
    End Sub

    Private Sub colorMovie_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles colorMovie.Click
        Dim i, j As Integer

        For i = 0 To Val(txtRows.Text) * 2 - 1
            For j = 0 To Val(txtColumns.Text) * 2 - 1
                blockColor(i, j, 0) = movieColor(currentFrame, i, j, 0)
                blockColor(i, j, 1) = movieColor(currentFrame, i, j, 1)
                blockColor(i, j, 2) = movieColor(currentFrame, i, j, 2)
            Next
        Next
        colorDisplay.Refresh()
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        If checkEnableSerial.Checked = True Then
            SerialPort1.Write(Chr(&H40))
            SerialPort1.Write(Chr(&HFF))
            SerialPort1.Close()
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReDim blockColor(Val(txtRows.Text) * 2 - 1, Val(txtColumns.Text) * 2 - 1, 2)
        ReDim movieColor(1000, Val(txtRows.Text) * 2 - 1, Val(txtColumns.Text) * 2 - 1, 2)
        ReDim moviePeriod(1000)
        currentFrame = 0
        totalFrames = 0
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Me.Refresh()
    End Sub

    Private Sub buttonAddChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonAddChange.Click
        Dim i, j As Integer

        For i = 0 To Val(txtRows.Text) * 2 - 1
            For j = 0 To Val(txtColumns.Text) * 2 - 1
                movieColor(currentFrame, i, j, 0) = blockColor(i, j, 0)
                movieColor(currentFrame, i, j, 1) = blockColor(i, j, 1)
                movieColor(currentFrame, i, j, 2) = blockColor(i, j, 2)
            Next
        Next

        moviePeriod(currentFrame) = Val(txtPeriod.Text)

        If currentFrame = totalFrames Then
            totalFrames = totalFrames + 1
            HScrollBar1.Maximum = totalFrames
            HScrollBar1.Value = currentFrame
            buttonAddChange.Text = "Update"
        End If

        colorMovie.Refresh()
    End Sub

    Private Sub HScrollBar1_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles HScrollBar1.ValueChanged
        currentFrame = HScrollBar1.Value
        If currentFrame = totalFrames Then
            buttonAddChange.Text = "Add"
        Else
            buttonAddChange.Text = "Update"
        End If
        txtPeriod.Text = Trim(moviePeriod(currentFrame))
        colorMovie.Refresh()
    End Sub

    Private Sub txtPeriod_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPeriod.TextChanged
        If Val(txtPeriod.Text) < 50 Then txtPeriod.Text = "50"
    End Sub

    Private Sub buttonLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonLoad.Click
        Dim myStream As System.IO.FileStream = Nothing
        Dim openFileDialog1 As New OpenFileDialog()
        Dim theLine As String
        Dim i As Integer

        openFileDialog1.Filter = "blm files (*.blm)|*.blm|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 1
        openFileDialog1.RestoreDirectory = True

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                myStream = openFileDialog1.OpenFile()
                If (myStream IsNot Nothing) Then
                    ' Insert code to read the stream here.
                    Dim sr As New System.IO.StreamReader(myStream)
                    txtInfo.Text = ""
                    currentFrame = 0
                    totalFrames = 0
                    theLine = sr.ReadLine()
                    Do
                        If Mid(theLine, 1, 1) = "#" Then txtInfo.Text = txtInfo.Text & theLine & vbCrLf
                        If Mid(theLine, 1, 1) = "@" Then
                            moviePeriod(currentFrame) = Val(Mid(theLine, 2))
                            txtInfo.Text = txtInfo.Text & theLine & vbCrLf
                            For i = 0 To 3
                                theLine = sr.ReadLine()
                                movieColor(currentFrame, 0, i, 0) = Val("&H" & Mid(theLine, 1, 1)) * 17
                                movieColor(currentFrame, 1, i, 0) = Val("&H" & Mid(theLine, 2, 1)) * 17
                                movieColor(currentFrame, 2, i, 0) = Val("&H" & Mid(theLine, 3, 1)) * 17
                                movieColor(currentFrame, 3, i, 0) = Val("&H" & Mid(theLine, 4, 1)) * 17
                                movieColor(currentFrame, 0, i, 1) = Val("&H" & Mid(theLine, 6, 1)) * 17
                                movieColor(currentFrame, 1, i, 1) = Val("&H" & Mid(theLine, 7, 1)) * 17
                                movieColor(currentFrame, 2, i, 1) = Val("&H" & Mid(theLine, 8, 1)) * 17
                                movieColor(currentFrame, 3, i, 1) = Val("&H" & Mid(theLine, 9, 1)) * 17
                                movieColor(currentFrame, 0, i, 2) = Val("&H" & Mid(theLine, 11, 1)) * 17
                                movieColor(currentFrame, 1, i, 2) = Val("&H" & Mid(theLine, 12, 1)) * 17
                                movieColor(currentFrame, 2, i, 2) = Val("&H" & Mid(theLine, 13, 1)) * 17
                                movieColor(currentFrame, 3, i, 2) = Val("&H" & Mid(theLine, 14, 1)) * 17
                                txtInfo.Text = txtInfo.Text & theLine & vbCrLf
                            Next

                            currentFrame = currentFrame + 1
                            totalFrames = totalFrames + 1
                        End If
                        theLine = sr.ReadLine()
                    Loop Until theLine Is Nothing
                    sr.Close()
                End If
            Catch Ex As Exception
                MessageBox.Show("Cannot read file from disk. Original error: " & Ex.Message)
            Finally
                ' Check this again, since we need to make sure we didn't throw an exception on open.
                If (myStream IsNot Nothing) Then
                    myStream.Close()
                End If
            End Try
        End If

        HScrollBar1.Maximum = totalFrames
        HScrollBar1.Value = currentFrame

    End Sub

    Private Sub buttonSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonSave.Click
        Dim myStream As System.IO.FileStream = Nothing
        Dim saveFileDialog1 As New SaveFileDialog()
        Dim frame, i As Integer

        saveFileDialog1.Filter = "blm files (*.blm)|*.blm|All files (*.*)|*.*"
        saveFileDialog1.FilterIndex = 1
        saveFileDialog1.RestoreDirectory = True

        If saveFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                myStream = saveFileDialog1.OpenFile()
                If (myStream IsNot Nothing) Then
                    ' Insert code to read the stream here.
                    Dim sw As New System.IO.StreamWriter(myStream)
                    For frame = 0 To totalFrames - 1
                        currentFrame = frame
                        sw.WriteLine("@" & Trim(moviePeriod(currentFrame)))
                        For i = 0 To 3
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 0, i, 0) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 1, i, 0) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 2, i, 0) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 3, i, 0) / 17))))
                            sw.Write(".")
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 0, i, 1) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 1, i, 1) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 2, i, 1) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 3, i, 1) / 17))))
                            sw.Write(".")
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 0, i, 2) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 1, i, 2) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 2, i, 2) / 17))))
                            sw.Write(Trim(Hex(Int(movieColor(currentFrame, 3, i, 2) / 17))))
                            sw.Write(vbCrLf)
                        Next
                        sw.Write(vbCrLf)
                    Next
                    sw.Close()
                End If
            Catch Ex As Exception
                MessageBox.Show("Cannot write to disk. Original error: " & Ex.Message)
            Finally
                ' Check this again, since we need to make sure we didn't throw an exception on open.
                If (myStream IsNot Nothing) Then
                    myStream.Close()
                End If
            End Try
        End If
    End Sub

    Private Sub buttonPlayStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonPlayStop.Click
        If buttonPlayStop.Text = "Play Movie" Then
            currentFrame = 0
            If moviePeriod(currentFrame + 1) > 0 Then timerPlayMovie.Interval = moviePeriod(currentFrame + 1)
            timerPlayMovie.Enabled = True
            buttonPlayStop.Text = "Stop Movie"
        ElseIf buttonPlayStop.Text = "Stop Movie" Then
            timerPlayMovie.Enabled = False
            buttonPlayStop.Text = "Play Movie"
        End If
    End Sub

    Private Sub timerPlayMovie_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timerPlayMovie.Tick
        Dim tempData As String

        If moviePeriod(currentFrame) > 0 Then timerPlayMovie.Interval = moviePeriod(currentFrame) * scrollBarSpeed.Value / 10
        colorMovie.Refresh()
        HScrollBar1.Value = currentFrame

        If checkEnableSerial.Checked = True Then
            tempData = Chr(&H10)
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 1, 0) / 17) * 16 + Int(movieColor(currentFrame, 1, 1, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 1, 2) / 17) * 16 + Int(movieColor(currentFrame, 0, 1, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 0, 1, 1) / 17) * 16 + Int(movieColor(currentFrame, 0, 1, 2) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 0, 0) / 17) * 16 + Int(movieColor(currentFrame, 1, 0, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 0, 2) / 17) * 16 + Int(movieColor(currentFrame, 0, 0, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 0, 0, 1) / 17) * 16 + Int(movieColor(currentFrame, 0, 0, 2) / 17))
            tempData = tempData & Chr(&H1)
            SerialPort1.Write(tempData)

            tempData = Chr(&H10)
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 1, 0) / 17) * 16 + Int(movieColor(currentFrame, 3, 1, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 1, 2) / 17) * 16 + Int(movieColor(currentFrame, 2, 1, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 2, 1, 1) / 17) * 16 + Int(movieColor(currentFrame, 2, 1, 2) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 0, 0) / 17) * 16 + Int(movieColor(currentFrame, 3, 0, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 0, 2) / 17) * 16 + Int(movieColor(currentFrame, 2, 0, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 2, 0, 1) / 17) * 16 + Int(movieColor(currentFrame, 2, 0, 2) / 17))
            tempData = tempData & Chr(&H2)
            SerialPort1.Write(tempData)

            tempData = Chr(&H10)
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 3, 0) / 17) * 16 + Int(movieColor(currentFrame, 1, 3, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 3, 2) / 17) * 16 + Int(movieColor(currentFrame, 0, 3, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 0, 3, 1) / 17) * 16 + Int(movieColor(currentFrame, 0, 3, 2) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 2, 0) / 17) * 16 + Int(movieColor(currentFrame, 1, 2, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 1, 2, 2) / 17) * 16 + Int(movieColor(currentFrame, 0, 2, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 0, 2, 1) / 17) * 16 + Int(movieColor(currentFrame, 0, 2, 2) / 17))
            tempData = tempData & Chr(&H3)
            SerialPort1.Write(tempData)

            tempData = Chr(&H10)
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 3, 0) / 17) * 16 + Int(movieColor(currentFrame, 3, 3, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 3, 2) / 17) * 16 + Int(movieColor(currentFrame, 2, 3, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 2, 3, 1) / 17) * 16 + Int(movieColor(currentFrame, 2, 3, 2) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 2, 0) / 17) * 16 + Int(movieColor(currentFrame, 3, 2, 1) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 3, 2, 2) / 17) * 16 + Int(movieColor(currentFrame, 2, 2, 0) / 17))
            tempData = tempData & Chr(Int(movieColor(currentFrame, 2, 2, 1) / 17) * 16 + Int(movieColor(currentFrame, 2, 2, 2) / 17))
            tempData = tempData & Chr(&H4)
            SerialPort1.Write(tempData)
        End If

        currentFrame = currentFrame + 1
        If currentFrame >= totalFrames Then currentFrame = 0
    End Sub

    Private Sub checkEnableSerial_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkEnableSerial.CheckedChanged
        If checkEnableSerial.Checked = True Then
            SerialPort1.StopBits = IO.Ports.StopBits.One
            SerialPort1.BaudRate = 19200
            SerialPort1.Parity = IO.Ports.Parity.None
            SerialPort1.DataBits = 8
            SerialPort1.PortName = "COM3"
            SerialPort1.Encoding = System.Text.Encoding.GetEncoding(1252)
            SerialPort1.Open()
            Control.CheckForIllegalCrossThreadCalls = False
        Else
            SerialPort1.Write(Chr(&H40))
            SerialPort1.Write(Chr(&HFF))
            SerialPort1.Close()
        End If
    End Sub
End Class
